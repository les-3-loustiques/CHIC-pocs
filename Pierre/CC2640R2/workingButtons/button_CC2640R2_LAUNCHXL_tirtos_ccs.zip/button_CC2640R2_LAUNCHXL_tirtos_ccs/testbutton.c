/*
 * Copyright (c) 2016-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *    ======== testbutton.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <string.h>

/* POSIX Header files */
#include <pthread.h>
#include <semaphore.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/display/Display.h>

/* Module Header */
#include <ti/sail/button/button.h>
#include <ti/sail/led/led.h>

/* Example/Board Header files */
#include "Board.h"


#define CB_TASK_STACK_SIZE    2048
typedef struct buttonStats
{
    unsigned int pressed;
    unsigned int clicked;
    unsigned int released;
    unsigned int longPress;
    unsigned int longClicked;
    unsigned int doubleclicked;
    unsigned int lastpressedduration;
} buttonStats;

typedef struct cbParams{
Button_Handle    buttonHandle;
Button_EventMask buttonEvents;
}cbParams;

typedef struct cbParamList
{
  cbParams cbParams[10];
  volatile unsigned char paramsHead;
  unsigned char paramsTail;
} cbParamList;

Button_Handle buttonHandle[Board_BUTTONCOUNT];
buttonStats   LaunchpadbuttonStats[Board_BUTTONCOUNT];
LED_Handle    ledHandle[Board_LEDCOUNT];
sem_t  ButtonSem;
cbParamList callBackParamList;

static Display_Handle display;

pthread_t cbTask;

static void HandlebuttonCallback(Button_Handle buttonHandle,Button_EventMask buttonEvents)
{
    callBackParamList.cbParams[callBackParamList.paramsHead].buttonHandle =buttonHandle;
    callBackParamList.cbParams[callBackParamList.paramsHead++].buttonEvents  =buttonEvents;
    if (callBackParamList.paramsHead >= 10)
    {
        callBackParamList.paramsHead = 0;
    }
    sem_post(&ButtonSem);
}

/*
 *  ======== ButtonCBTask ========
 *  This task is unblocked when button callback happens.The counting semaphore
 *  executes
 */
void *ButtonCBTask(void *arg0)
{
    buttonStats *buttonStatsPtr = NULL;
    unsigned int i;
    while(1)
    {
        /* Pend on semaphore, ButtonSem */
        if(0 == sem_wait(&ButtonSem))
        {
            while(callBackParamList.paramsHead != callBackParamList.paramsTail)
            {
                cbParams cbParam = callBackParamList.cbParams[callBackParamList
                                .paramsTail++];
                if(callBackParamList.paramsTail >= 10)
                {
                    callBackParamList.paramsTail = 0;
                }
                for(i =0;i< Board_BUTTONCOUNT; i++)
                {
                    if(cbParam.buttonHandle == buttonHandle[i])
                    {
                        buttonStatsPtr = &LaunchpadbuttonStats[i];
                        break;
                    }
                }
                if(buttonStatsPtr == NULL)
                {
                    return 0;
                }
                if(BUTTON_EV_PRESSED == (cbParam.buttonEvents & BUTTON_EV_PRESSED))
                {
                    buttonStatsPtr->pressed++;
                }
                if(BUTTON_EV_RELEASED == (cbParam.buttonEvents & BUTTON_EV_RELEASED))
                {
                    buttonStatsPtr->released++;
                }
                if(BUTTON_EV_CLICKED == (cbParam.buttonEvents & BUTTON_EV_CLICKED))
                {
                    buttonStatsPtr->clicked++;
                    Display_print0(display, 0, 0, "Button:Click\n");
                    buttonStatsPtr->lastpressedduration =
                                                Button_getLastPressedDuration(cbParam.buttonHandle);

                    if(cbParam.buttonHandle == buttonHandle[Board_BUTTON0])
                    {
                       if(LED_STATE_BLINKING == LED_getState(ledHandle[Board_LED0]))
                       {
                           LED_stopBlinking(ledHandle[Board_LED0]);
                        LED_setOff(ledHandle[Board_LED0]);
                       }
                       else
                       {
                       LED_toggle(ledHandle[Board_LED0]);
                       }
                    }
                    else
                    {
                       if(LED_STATE_BLINKING == LED_getState(ledHandle[Board_LED1]))
                       {
                           LED_stopBlinking(ledHandle[Board_LED1]);
                           LED_setOff(ledHandle[Board_LED1]);
                       }
                       else
                       {
                           LED_toggle(ledHandle[Board_LED1]);
                       }

                    }
                }
                if(BUTTON_EV_LONGPRESSED == (cbParam.buttonEvents & BUTTON_EV_LONGPRESSED))
                {
                    buttonStatsPtr->longPress++;
                    Display_print0(display, 0, 0, "Button:Long Press\n");
                    if(cbParam.buttonHandle == buttonHandle[Board_BUTTON0])
                    {
                        LED_startBlinking(ledHandle[Board_LED0], 500);
                    }
                    else
                    {
                        LED_startBlinking(ledHandle[Board_LED1], 500);
                    }
                }
                if(BUTTON_EV_LONGCLICKED == (cbParam.buttonEvents & BUTTON_EV_LONGCLICKED))
                {
                    buttonStatsPtr->longClicked++;
                    buttonStatsPtr->lastpressedduration =
                                               Button_getLastPressedDuration(cbParam.buttonHandle);
                    if(cbParam.buttonHandle == buttonHandle[Board_BUTTON0])
                    {
                        LED_stopBlinking(ledHandle[Board_LED0]);
                    }
                    else
                    {
                        LED_stopBlinking(ledHandle[Board_LED1]);
                    }
                }
                if(BUTTON_EV_DOUBLECLICKED == (cbParam.buttonEvents & BUTTON_EV_DOUBLECLICKED))
                {
                    buttonStatsPtr->doubleclicked++;
                    Display_print0(display, 0, 0, "Button:Double Click\n");
                    if(cbParam.buttonHandle == buttonHandle[Board_BUTTON0])
                    {
                        if(LED_STATE_BLINKING != LED_getState(ledHandle[Board_LED0]))
                        {
                            LED_startBlinking(ledHandle[Board_LED0], 100);
                        }
                        else
                        {
                            LED_stopBlinking(ledHandle[Board_LED0]);
                            LED_setOff(ledHandle[Board_LED0]);
                        }
                    }
                    else
                    {
                        if(LED_STATE_BLINKING != LED_getState(ledHandle[Board_LED1]))
                        {
                            LED_startBlinking(ledHandle[Board_LED1], 100);
                        }
                        else
                        {
                            LED_stopBlinking(ledHandle[Board_LED1]);
                            LED_setOff(ledHandle[Board_LED1]);
                        }
                    }
                }
                else
                {
                }
            }
        }
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    Button_Params buttonParams;
    LED_Params  ledParams;
    PWM_Params  pwmParams;
    PWM_Handle  pwmHandle = NULL;
    uint16_t    pwmPeriod = 3000;      /* Period in microseconds*/
    int retc;
    pthread_attr_t       pAttrs;


    GPIO_init();
    PWM_init();

    /* Open the HOST display for output */
    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }
    Display_print0(display, 0, 0, "Starting the button example...\n\n");

    callBackParamList.paramsTail = 0;
    callBackParamList.paramsHead = 0;

    if(0 != sem_init(&ButtonSem, 0, 0))
    {
        /* sem_init() failed */
        Display_print0(display, 0, 0, "Semaphore creation failed");
        while (1);
    }
	
    pthread_attr_init(&pAttrs);
    pthread_attr_setstacksize(&pAttrs, CB_TASK_STACK_SIZE);
    retc = pthread_create(&cbTask, &pAttrs, ButtonCBTask, NULL);
    if (retc != 0) {
        /* pthread_create() failed */
        Display_print0(display, 0, 0, "Button Callback Task creation failed");
        while (1);
    }

    /*clear the LaunchPad button statistics */
    memset(&LaunchpadbuttonStats, 0, sizeof(LaunchpadbuttonStats));
    Display_print0(display, 0, 0, "Button LED module demo...\n");

    Button_init();
    /*initialize button parameters to default*/
    Button_initParams(&buttonParams);
    //buttonParams.buttonEventMask = 0xDF;
    /*open button 1 and button 2 */
    buttonHandle[Board_BUTTON0] = Button_open(Board_BUTTON0, &buttonParams, HandlebuttonCallback);
    buttonHandle[Board_BUTTON1] = Button_open(Board_BUTTON1, &buttonParams, HandlebuttonCallback);
    /* Check if the button open is successful */
    if ((buttonHandle[Board_BUTTON1]  == NULL)|| (buttonHandle[Board_BUTTON0]  == NULL)) {
        Display_print0(display, 0, 0, "button Open Failed!");
    }

    LED_init();
    /* Initialize ledParams structure to defaults */
    LED_initParams(&ledParams);


    PWM_Params_init(&pwmParams);
    pwmParams.dutyUnits = PWM_DUTY_US;
    pwmParams.dutyValue = 0;
    pwmParams.periodUnits = PWM_PERIOD_US;
    pwmParams.periodValue = pwmPeriod;
    pwmHandle = PWM_open(Board_PWM0, &pwmParams);
    if (pwmHandle == NULL) {
        Display_print0(display, 0, 0, "Board_PWM0 did not open");
    }
    PWM_start(pwmHandle);

    LED_initParams(&ledParams);
    /* Set the ledType to PWM controlled*/
    ledParams.ledType = LED_PWM_CONTROLLED;
    ledParams.setState   = LED_STATE_OFF;
    ledParams.pwmHandle = pwmHandle;
    ledParams.pwmPeriod = pwmPeriod;
    ledParams.brightness = 100;
    /* Open LED sensor with custom Params */
    ledHandle[Board_LED0] = LED_open(Board_LED0, &ledParams);

    LED_initParams(&ledParams);
    /* Set the ledType to PWM controlled*/
    ledParams.ledType = LED_GPIO_CONTROLLED;
    /* Open LED sensor with custom Params */
    ledHandle[Board_LED1] = LED_open(Board_LED1, &ledParams);
    /* Check if the open is successful */
    if ((ledHandle[Board_LED0] == NULL) || (ledHandle[Board_LED1] == NULL)) {
        Display_print0(display, 0, 0, "Board LED Open Failed!");
    }
    pthread_attr_destroy(&pAttrs);

    return 0;
}
