## Example Summary

This Example demonstrates the usage of  **SAIL module : Button**. Internally the example uses GPIO driver, posix timer modules to interface push buttons and the LED.
The example allows users to perform actions with push buttons available on LaunchPads. Following observations can be made while using the example

* On short press (regular press) of push button user can observe togling of LED.
* On long press of push button the same led starts blinking and on release the LED turns off.
* Double click of the push button again blinks the corresponding LED in different speed.(on pressing the same button again, the LED turns off)

__Note: This example does not work as is the LPDS(Low Power Deep Sleep) mode (if power policy is enabled). There is a SimpleLink 
academy lab session on modifying this Button example to make it work in LPDS mode, Please refer to that in case
you would like to make use of the button module in LPDS mode.__

## Peripherals Exercised

* `Board_LED1`    - visual feedback for push button Board_Button0
* `Board_LED2`    - visual feedback for push button Board_Button1
* `Board_BUTTON0` - interfaced to push button
* `Board_BUTTON1` - interfaced to push button

## Resources & Jumper Settings

> If you're using an IDE (such as CCS or IAR), please refer to Board.html in your project
directory for resources used and board-specific jumper settings. Otherwise, you can find
Board.html in the directory &lt;PLUGIN_INSTALL_DIR&gt;/source/ti/boards/&lt;BOARD&gt;.

## Example Usage

* Open a serial session (e.g. [`PuTTY`](http://www.putty.org/ "PuTTY's Homepage"),teraterm, CCS terminal, etc.) to the appropriate COM port.
    * The COM port can be determined via Device Manager in Windows or via `ls /dev/tty*` in Linux.

The connection will have the following settings:
```
    Baud-rate:     115200
    Data bits:          8
    Stop bits:          1
    Parity:          None
    Flow Control:    None
```

* Run the example.

* Do a  button click.LED should toggle its state

* Do a long press on push button the after long press detection led should blink at a speed on releasing the LED blinking will stop

* Do a double click  on push button, the led should blink at a higher speed.On clicking push button the blinking should stop

> Two push buttons are interfaced in this example.

__NOTE: Buttons may not work on some LaunchPads when some BoosterPacks are connected to it(pin conflicts), Make sure no BoosterPack is connected to LaunchPad before running this example__

## Application Design Details

* There are two threads, `mainThread` and `ButtonCBTask`.
    * The mainThread sets up the button example
        * It initilizes the peripheral GPIO, Display module and opens instances of Button and Led module.(in case of any failure the error messages are shown on the UART Console)
        * It starts the button callback task, which blocks on semaphore ButtonSem.(this semaphire is created in the mainthread task)
        * Finally after setting up the example,this task exits.
    * The button callback task performs following actions.
        * This task blocks on the semaphore ButtonSem. ButtonSem is posted by the **buttoncallback** fucntion(this function is called in interrupt context from the Button module, this callback stores the button event in global circular buffer and then posts the semaphore).
        * Then this task checks the circular buffer and depending on the button and the event type performs action such as togle of LED, blinking etc.
