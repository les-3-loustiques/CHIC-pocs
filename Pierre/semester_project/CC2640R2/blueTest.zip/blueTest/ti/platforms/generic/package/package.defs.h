/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_platforms_generic__
#define ti_platforms_generic__



#endif /* ti_platforms_generic__ */ 
