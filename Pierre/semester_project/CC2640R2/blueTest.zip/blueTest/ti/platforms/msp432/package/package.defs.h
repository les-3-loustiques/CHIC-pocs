/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_platforms_msp432__
#define ti_platforms_msp432__



#endif /* ti_platforms_msp432__ */ 
