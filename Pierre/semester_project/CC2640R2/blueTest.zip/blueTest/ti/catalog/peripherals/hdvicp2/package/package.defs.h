/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_catalog_peripherals_hdvicp2__
#define ti_catalog_peripherals_hdvicp2__



#endif /* ti_catalog_peripherals_hdvicp2__ */ 
