/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#include <xdc/std.h>

__FAR__ char ti_catalog_arm_cortexm4__dummy__;

#define __xdc_PKGVERS 1, 0, 0
#define __xdc_PKGNAME ti.catalog.arm.cortexm4
#define __xdc_PKGPREFIX ti_catalog_arm_cortexm4_

#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

