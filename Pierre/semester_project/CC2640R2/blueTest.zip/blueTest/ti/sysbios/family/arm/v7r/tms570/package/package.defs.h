/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_v7r_tms570__
#define ti_sysbios_family_arm_v7r_tms570__


/*
 * ======== module ti.sysbios.family.arm.v7r.tms570.Boot ========
 */


/*
 * ======== module ti.sysbios.family.arm.v7r.tms570.Core ========
 */

typedef struct ti_sysbios_family_arm_v7r_tms570_Core_Fxns__ ti_sysbios_family_arm_v7r_tms570_Core_Fxns__;
typedef const struct ti_sysbios_family_arm_v7r_tms570_Core_Fxns__* ti_sysbios_family_arm_v7r_tms570_Core_Module;


#endif /* ti_sysbios_family_arm_v7r_tms570__ */ 
