/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_v7r_keystone3__
#define ti_sysbios_family_arm_v7r_keystone3__


/*
 * ======== module ti.sysbios.family.arm.v7r.keystone3.Core ========
 */

typedef struct ti_sysbios_family_arm_v7r_keystone3_Core_Fxns__ ti_sysbios_family_arm_v7r_keystone3_Core_Fxns__;
typedef const struct ti_sysbios_family_arm_v7r_keystone3_Core_Fxns__* ti_sysbios_family_arm_v7r_keystone3_Core_Module;

/*
 * ======== module ti.sysbios.family.arm.v7r.keystone3.Hwi ========
 */

typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_InterruptGroup ti_sysbios_family_arm_v7r_keystone3_Hwi_InterruptGroup;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_VIM ti_sysbios_family_arm_v7r_keystone3_Hwi_VIM;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Module_State ti_sysbios_family_arm_v7r_keystone3_Hwi_Module_State;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Fxns__ ti_sysbios_family_arm_v7r_keystone3_Hwi_Fxns__;
typedef const struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Fxns__* ti_sysbios_family_arm_v7r_keystone3_Hwi_Module;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Params ti_sysbios_family_arm_v7r_keystone3_Hwi_Params;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Object ti_sysbios_family_arm_v7r_keystone3_Hwi_Object;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Struct;
typedef ti_sysbios_family_arm_v7r_keystone3_Hwi_Object* ti_sysbios_family_arm_v7r_keystone3_Hwi_Handle;
typedef struct ti_sysbios_family_arm_v7r_keystone3_Hwi_Object__ ti_sysbios_family_arm_v7r_keystone3_Hwi_Instance_State;
typedef ti_sysbios_family_arm_v7r_keystone3_Hwi_Object* ti_sysbios_family_arm_v7r_keystone3_Hwi_Instance;

/*
 * ======== module ti.sysbios.family.arm.v7r.keystone3.TimerSupport ========
 */

typedef struct ti_sysbios_family_arm_v7r_keystone3_TimerSupport_Fxns__ ti_sysbios_family_arm_v7r_keystone3_TimerSupport_Fxns__;
typedef const struct ti_sysbios_family_arm_v7r_keystone3_TimerSupport_Fxns__* ti_sysbios_family_arm_v7r_keystone3_TimerSupport_Module;


#endif /* ti_sysbios_family_arm_v7r_keystone3__ */ 
