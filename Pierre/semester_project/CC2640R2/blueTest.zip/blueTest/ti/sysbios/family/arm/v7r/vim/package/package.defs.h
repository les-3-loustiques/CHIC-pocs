/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_v7r_vim__
#define ti_sysbios_family_arm_v7r_vim__


/*
 * ======== module ti.sysbios.family.arm.v7r.vim.Hwi ========
 */

typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_VIM ti_sysbios_family_arm_v7r_vim_Hwi_VIM;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Module_State ti_sysbios_family_arm_v7r_vim_Hwi_Module_State;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Fxns__ ti_sysbios_family_arm_v7r_vim_Hwi_Fxns__;
typedef const struct ti_sysbios_family_arm_v7r_vim_Hwi_Fxns__* ti_sysbios_family_arm_v7r_vim_Hwi_Module;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Params ti_sysbios_family_arm_v7r_vim_Hwi_Params;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Object ti_sysbios_family_arm_v7r_vim_Hwi_Object;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Struct ti_sysbios_family_arm_v7r_vim_Hwi_Struct;
typedef ti_sysbios_family_arm_v7r_vim_Hwi_Object* ti_sysbios_family_arm_v7r_vim_Hwi_Handle;
typedef struct ti_sysbios_family_arm_v7r_vim_Hwi_Object__ ti_sysbios_family_arm_v7r_vim_Hwi_Instance_State;
typedef ti_sysbios_family_arm_v7r_vim_Hwi_Object* ti_sysbios_family_arm_v7r_vim_Hwi_Instance;


#endif /* ti_sysbios_family_arm_v7r_vim__ */ 
