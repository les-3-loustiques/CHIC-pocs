/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_cc32xx__
#define ti_sysbios_family_arm_cc32xx__


/*
 * ======== module ti.sysbios.family.arm.cc32xx.Seconds ========
 */

typedef struct ti_sysbios_family_arm_cc32xx_Seconds_Module_State ti_sysbios_family_arm_cc32xx_Seconds_Module_State;
typedef struct ti_sysbios_family_arm_cc32xx_Seconds_Fxns__ ti_sysbios_family_arm_cc32xx_Seconds_Fxns__;
typedef const struct ti_sysbios_family_arm_cc32xx_Seconds_Fxns__* ti_sysbios_family_arm_cc32xx_Seconds_Module;

/*
 * ======== module ti.sysbios.family.arm.cc32xx.Timer ========
 */

typedef struct ti_sysbios_family_arm_cc32xx_Timer_Module_State ti_sysbios_family_arm_cc32xx_Timer_Module_State;
typedef struct ti_sysbios_family_arm_cc32xx_Timer_Fxns__ ti_sysbios_family_arm_cc32xx_Timer_Fxns__;
typedef const struct ti_sysbios_family_arm_cc32xx_Timer_Fxns__* ti_sysbios_family_arm_cc32xx_Timer_Module;
typedef struct ti_sysbios_family_arm_cc32xx_Timer_Params ti_sysbios_family_arm_cc32xx_Timer_Params;
typedef struct ti_sysbios_family_arm_cc32xx_Timer_Object ti_sysbios_family_arm_cc32xx_Timer_Object;
typedef struct ti_sysbios_family_arm_cc32xx_Timer_Struct ti_sysbios_family_arm_cc32xx_Timer_Struct;
typedef ti_sysbios_family_arm_cc32xx_Timer_Object* ti_sysbios_family_arm_cc32xx_Timer_Handle;
typedef struct ti_sysbios_family_arm_cc32xx_Timer_Object__ ti_sysbios_family_arm_cc32xx_Timer_Instance_State;
typedef ti_sysbios_family_arm_cc32xx_Timer_Object* ti_sysbios_family_arm_cc32xx_Timer_Instance;

/*
 * ======== module ti.sysbios.family.arm.cc32xx.TimestampProvider ========
 */

typedef struct ti_sysbios_family_arm_cc32xx_TimestampProvider_Fxns__ ti_sysbios_family_arm_cc32xx_TimestampProvider_Fxns__;
typedef const struct ti_sysbios_family_arm_cc32xx_TimestampProvider_Fxns__* ti_sysbios_family_arm_cc32xx_TimestampProvider_Module;


#endif /* ti_sysbios_family_arm_cc32xx__ */ 
