/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D20
 */

#ifndef ti_sysbios_family_arm_gicv3__
#define ti_sysbios_family_arm_gicv3__


/*
 * ======== module ti.sysbios.family.arm.gicv3.Hwi ========
 */

typedef struct ti_sysbios_family_arm_gicv3_Hwi_IntAffinity ti_sysbios_family_arm_gicv3_Hwi_IntAffinity;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_SgiIntAffinity ti_sysbios_family_arm_gicv3_Hwi_SgiIntAffinity;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_ExcContext ti_sysbios_family_arm_gicv3_Hwi_ExcContext;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Gicd ti_sysbios_family_arm_gicv3_Hwi_Gicd;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Gicr ti_sysbios_family_arm_gicv3_Hwi_Gicr;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Gics ti_sysbios_family_arm_gicv3_Hwi_Gics;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Gicc ti_sysbios_family_arm_gicv3_Hwi_Gicc;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_GicRegisterMap ti_sysbios_family_arm_gicv3_Hwi_GicRegisterMap;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Module_State ti_sysbios_family_arm_gicv3_Hwi_Module_State;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Fxns__ ti_sysbios_family_arm_gicv3_Hwi_Fxns__;
typedef const struct ti_sysbios_family_arm_gicv3_Hwi_Fxns__* ti_sysbios_family_arm_gicv3_Hwi_Module;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Params ti_sysbios_family_arm_gicv3_Hwi_Params;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Object ti_sysbios_family_arm_gicv3_Hwi_Object;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Struct ti_sysbios_family_arm_gicv3_Hwi_Struct;
typedef ti_sysbios_family_arm_gicv3_Hwi_Object* ti_sysbios_family_arm_gicv3_Hwi_Handle;
typedef struct ti_sysbios_family_arm_gicv3_Hwi_Object__ ti_sysbios_family_arm_gicv3_Hwi_Instance_State;
typedef ti_sysbios_family_arm_gicv3_Hwi_Object* ti_sysbios_family_arm_gicv3_Hwi_Instance;


#endif /* ti_sysbios_family_arm_gicv3__ */ 
